function sayHello() {
    alert("Hello! GitHub Pages is working.");
}